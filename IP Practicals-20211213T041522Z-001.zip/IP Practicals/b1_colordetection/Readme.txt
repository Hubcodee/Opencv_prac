RUN IN TERMINAL LIKE THIS:

python color_detection.py -i <add your image path here>